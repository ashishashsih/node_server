import db from '../config/dbconfig.js'; // Note the .js extension
export const getAllUsers = async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM users');

    if (rows.length === 0)
    {
      return res.status(404).json({ status:false,message: 'No users found.' });
    }

    res.status(200).json({
      status:true,
      message: 'Users fetched successfully',
      count: rows.length,
      data: rows
    });

  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      message: 'An error occurred while retrieving users.',
      error: error.message
    });
  }
};

/**
 * Creates a new user in the 'users' table.
 * Assuming body contains: name, contact, email, password, role_id
 */
export const createUser = async (req, res) =>
{
    const { name, contact, email, password, role_id } = req.body;

    // Basic validation (you should add more robust validation)
    if (!name || !email || !password)
    {
      console.log(req.body.name);
        return res.status(400).json({ message: "Missing required fields: name, email, and password." });
    }

    // NOTE: In a real app, you must HASH THE PASSWORD before inserting!
    const created_at = new Date();
    const status = 1; // Example default status

    try {
        const query = `
            INSERT INTO users (name, contact, email, password, role_id, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)`;
        const [result] = await db.execute(query, [name, contact, email, password, role_id || 2, status, created_at]);
        res.status(201).json({
            message: 'User created successfully',
            userId: result.insertId,
            data: { name, email }
        });

    } catch (error) {
        // Handle common MySQL errors like duplicate entry (e.g., email unique constraint)
        console.error('Error creating user:', error);
        res.status(500).json({
            message: 'An error occurred while creating the user.',
            error: error.sqlMessage || error.message
        });
    }
};

export const deleteUser = async (req, res) =>
{
  const userId = req.params.id; // Get ID from the URL parameter

  if (!userId) {
    return res.status(400).json({ message: "User ID is required for deletion." });
  }

  try {
    const query = 'update users set status=0 WHERE id = ?';
    const [result] = await db.execute(query, [userId]);

    // Check if any row was affected
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: `User with ID ${userId} not found.` });
    }

    res.status(200).json({
      message: `User with ID ${userId} deleted successfully.`,
      deletedId: userId
    });

  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({
      message: 'An error occurred while deleting the user.',
      error: error.sqlMessage || error.message
    });
  }
};

export const updateUser = async (req, res) => {
  const userId = req.params.id;
  const { name, contact, email, password, role_id, status } = req.body;

  if (!userId) {
      return res.status(400).json({ message: "User ID is required for update." });
  }

  // Prepare fields to update
  const fields = [];
  const values = [];

  // Check which fields are present in the body and build the query dynamically
  if (name) { fields.push('name = ?'); values.push(name); }
  if (contact) { fields.push('contact = ?'); values.push(contact); }
  if (email) { fields.push('email = ?'); values.push(email); }
  if (password) { 
      // NOTE: In a real app, you must HASH THE NEW PASSWORD before updating!
      fields.push('password = ?'); 
      values.push(password); 
  }
  if (role_id) { fields.push('role_id = ?'); values.push(role_id); }
  if (status !== undefined) { fields.push('status = ?'); values.push(status); }

  // Check if there's anything to update besides updated_at
  if (fields.length === 0) {
      return res.status(400).json({ message: "No valid fields provided for update." });
  }
  
  // Add updated_at timestamp and the user ID to the values array
  fields.push('updated_at = ?'); 
  values.push(new Date()); 
  values.push(userId);

  try {
      const query = `UPDATE users SET ${fields.join(', ')} WHERE id = ?`;
      const [result] = await db.execute(query, values);

      if (result.affectedRows === 0) {
          return res.status(404).json({ message: `User with ID ${userId} not found or no changes were made.` });
      }

      res.status(200).json({
          message: `User with ID ${userId} updated successfully.`,
          updatedFields: req.body
      });

  } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({
          message: 'An error occurred while updating the user.',
          error: error.sqlMessage || error.message
      });
  }
};

export const loginUser=async(req,res)=>
{
  // const email = req.params.id;
  // const password = req.params.password;
  const { 
    name, 
    contact, 
    email, 
    password, 
    role_id 
} = req.body;

  try {
    const [rows] = await db.execute("SELECT * FROM users where email='"+email+"' and password='"+password+"'");

    if (rows.length === 0)
    {
      return res.status(404).json({ status:false,message: "SELECT * FROM users where email='"+email+"'"});
    }

    res.status(200).json({
      status:true,
      message: 'Users fetched successfully',
      count: rows.length,
      data: rows[0]
    });

  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      message: 'An error occurred while retrieving users.',
      error: error.message
    });
  }
};

export const getUserById=async(req,res)=>
{
  // const email = req.params.id;
  // const password = req.params.password;
  const id = req.body.id;

  try {
    const [rows] = await db.execute("SELECT * FROM users where id="+id);

    if (rows.length === 0)
    {
      return res.status(404).json({ status:false,message: "SELECT * FROM users where email='"+email+"'"});
    }

    res.status(200).json({
      status:true,
      message: 'Users fetched successfully',
      count: rows.length,
      data: rows[0]
    });

  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      message: 'An error occurred while retrieving users.',
      error: error.message
    });
  }
};