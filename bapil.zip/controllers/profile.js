
import db from '../config/dbconfig.js'; // Note the .js extension

export const getAllProfiles = async (req, res) => {
try {
const [rows] = await db.execute('SELECT * FROM profile');
if (rows.length === 0)
{
return res.status(404).json({ status:false,message: 'No profile found.' });
}
res.status(200).json({
status:true,
message: 'Profile fetched successfully',
count: rows.length,
data: rows
});
} catch (error) {
console.error('Error fetching profiles:', error);
res.status(500).json({
message: 'An error occurred while retrieving profiles.',
error: error.message
});
}
};

export const createProfile = async (req, res) =>
{
const { user_id, image, bank_name, account_no, upi_id } = req.body;
// Basic validation (you should add more robust validation)
if (!user_id || ! image || ! bank_name || ! account_no || ! upi_id)
{
console.log(req.body.name);
return res.status(400).json({ message:
"Missing required fields: data not found." });
}
// NOTE: In a real app, you must HASH THE PASSWORD before inserting!
const created_at = new Date();
const status = 1; // Example default status

try {
const query = `
INSERT INTO profile (user_id, image, bank_name, account_no, upi_id) VALUES (?, ?, ?, ?, ?)`;
const [result] = await db.execute(query, [user_id, image, bank_name, account_no, upi_id]);
res.status(201).json({
message: 'User created successfully',
userId: result.insertId,
data: { user_id, image, bank_name, account_no, upi_id }
});
} catch (error) {

// Handle common MySQL errors like duplicate entry (e.g., email unique constraint)
console.error('Error creating user:', error);

res.status(500).json({
message: 'An error occurred while creating the user.',
error: error.sqlMessage || error.message
});
}
};

export const updateProfile = async (req, res) =>
{
const { user_id, image, bank_name, account_no, upi_id } = req.body;
// Basic validation (you should add more robust validation)
if (!user_id || ! image || ! bank_name || ! account_no || ! upi_id)
{
console.log(req.body.name);
return res.status(400).json({ message:
"Missing required fields: data not found." });
}
// NOTE: In a real app, you must HASH THE PASSWORD before inserting!
const created_at = new Date();
const status = 1; // Example default status

try {
const query = " UPDATE profile SET user_id='"+user_id+"', image='"+image+"', bank_name='"+bank_name+"', account_no='"+account_no+"', upi_id='"+upi_id+"' where id="+req.body.id;
const [result] = await db.execute(query);
res.status(201).json({
message: 'Profile updated successfully',
data: { user_id, image, bank_name, account_no, upi_id }
});
} catch (error) {

// Handle common MySQL errors like duplicate entry (e.g., email unique constraint)
console.error('Error creating user:', error);

res.status(500).json({
message: 'An error occurred while creating the user.',
error: error.sqlMessage || error.message
});
}
};

export const deleteProfile = async (req, res) =>
{ const userId = req.params.id; // Get ID from the URL parameter
if (!userId) {
return res.status(400).json({ message: "ID is required for deletion."}); }
try {
const query = 'update profile set status=0 WHERE id = ?';
const [result] = await db.execute(query, [userId]);
// Check if any row was affected
if (result.affectedRows === 0) {
return res.status(404).json({ message: `User with ID not found.` });
}
res.status(200).json({
message: `User deleted successfully.`,
deletedId: userId
});
} catch (error) {
console.error('Error deleting profile:', error);
res.status(500).json({
message: 'An error occurred while deleting the profile.',
error: error.sqlMessage || error.message
});
}
};

export const getProfileById=async(req,res)=>
{
const id = req.body.id;
try {
const [rows] = await db.execute('SELECT * FROM profile where id='+id);
if (rows.length === 0)
{
return res.status(404).json({ status:false,message: 'data not found'});
}
res.status(200).json({
status:true,
message: 'Profile fetched successfully',
count: rows.length,
data: rows[0]
});
} catch (error) {
console.error('Error fetching Profile:', error);
res.status(500).json({
message: 'An error occurred while retrieving users.',
error: error.message
});
}
};