// routes/user.routes.js
import express from 'express';
import { getAllUsers, createUser, deleteUser, updateUser,loginUser,getUserById } from '../controllers/user.js'; // Note the .js extension

const router = express.Router();

router.get('/', getAllUsers);
router.post('/', createUser);
router.delete('/:id', deleteUser);
router.put('/:id', updateUser);
router.post('/login', loginUser);
router.post('/userById', getUserById);
export default router;