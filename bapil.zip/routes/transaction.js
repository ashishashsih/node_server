import express from 'express';
//import { getAllTransactions, createTransaction, deleteTransaction, updateTransaction, getTransactionById}
import { getAllTransactions, createTransaction, deleteTransaction, getTransactionById,getTransactionByUserId}
from '../controllers/transaction.js';

const router = express.Router();

router.get('/', getAllTransactions);
router.post('/', createTransaction);
router.delete('/:id', deleteTransaction);
//router.put('/:id', updateTransaction);
//router.post('/login', loginTransaction);
router.post('/getTransactionById', getTransactionById);
router.post('/getTransactionByUserId', getTransactionByUserId);


export default router;