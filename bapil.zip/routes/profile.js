import express from 'express';
import { getAllProfiles, createProfile, deleteProfile, updateProfile, getProfileById}
from '../controllers/profile.js';

const router = express.Router();

router.get('/', getAllProfiles);
router.post('/', createProfile);
router.delete('/:id', deleteProfile);
router.post('/updateprofile/:id', updateProfile);
//router.post('/login', loginProfile);
router.post('/getProfileById', getProfileById);


export default router;