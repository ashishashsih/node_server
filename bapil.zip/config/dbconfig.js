// config/db.config.js
import mysql from 'mysql2/promise';
import 'dotenv/config'; // Import dotenv and configure it immediately

// Create the connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port:3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

console.log("host is:"+process.env.DB_USER_PASSWORD);
// Test the connection
pool.getConnection()
  .then(connection => {
    console.log('✅ Successfully connected to the MySQL database!');
    connection.release();
  })
  .catch(err => {
    console.error('❌ Database connection failed:', err);
    process.exit(1);
  });

export default pool; // Use export default